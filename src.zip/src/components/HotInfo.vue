<template>
    <div class="hot_content">
      我是内容
    </div>
</template>

<script lang="ts" setup>

</script>

<style scoped>
  .hot_content{
    min-width:  200px;
  }
</style>
