<template>
  <div class="cc_content">
    <div class="cc_item" v-for="i in 5">
      <div class="cc_left">
        <el-span>titile</el-span>
        <el-span>desc</el-span>
        <div>
          <el-span>type</el-span>
          <el-span>tag</el-span>
        </div>
        <div>
          <el-span>auth</el-span>
          <el-span>time</el-span>
        </div>
      </div>
      <div class="cc_right">
          <el-image></el-image>
      </div>
    </div>

    <el-pagination
        small
        background
        layout="prev, pager, next"
        :total="50"
        class="cc_page"
    />
  </div>

</template>

<script setup lang="ts">

</script>

<style scoped>
.cc_content{
  width: 80%;
  margin: 10px auto;
}
 .cc_item{
   display: flex;
   //flex-direction: column;
   min-width: 500px;
   max-width: 800px;
   justify-content: space-between;
   margin: 10px;
 }
 .cc_left{
    display: flex;
    flex-direction: column;
  }
 .cc_page{
   display: flex;
   min-width: 500px;
   max-width: 800px;
   justify-content: center;
 }
</style>
