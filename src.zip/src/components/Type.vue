<template>
  <div>
    类型分类: <el-radio-group v-model="checkedType"  size="large">
             <el-radio-button v-for="(item,index) in types" :key="index" :label=item.typeName :value=item.typeId @change="checkType(item)" />

            </el-radio-group>
<!--    类型分类:<el-check-tag v-for="(item,index) in types" :key="index" :checked="item.check" type="primary" >-->
<!--      {{item.typeName}}-->
<!--    </el-check-tag>-->
  </div>
  <div>

    标签分类:
    <el-radio-group v-model="checkedTag"  size="large">
      <el-radio-button v-for="(item,index) in tags" :key="index" :label=item.tagName :value=item.tagName @change="showTag(item)" />
    </el-radio-group>

  </div>
</template>

<script lang="ts" setup>
import {onBeforeMount, reactive, ref} from "vue";
import {Tag, Type} from "@/DictType/DType";
import request from "@/utils/request";
import {ElNotification} from "element-plus";


    let types:Array<Type> = reactive([])

    /**
     *  获取全部的type分类
     */
    let tags:Array<Tag> = reactive([]);
    onBeforeMount(() => {
       request.get('/type/list').then((res) =>{

         types.push(...res.data)
       }).catch((e) =>{
         ElNotification.error("网络异常")
       })
    })

    let checkedType = ref({})
    let checkedTag = ref({})

    const checkType = (item:any) => {
      console.log(item.typeId)
      checkedType.value = item.typeId
      tags.splice(0,tags.length)
      //发送请求获取tag子标签
      request.get('/tag/list/'+item.typeId).then((res) => {
          tags.push(...res.data)
      })
    }
    const showTag = (item:any) => {
      checkedType.value = item.typeId
      request.get("/tag/"+item.tagId).then((res) => {

      })
    }
</script>

<style>

</style>
