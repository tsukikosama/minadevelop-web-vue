<template>
    <div>
      <Login></Login>
    </div>
</template>

<script setup lang="ts">

import Login from "@/components/Login.vue";
</script>


<style scoped>

</style>
