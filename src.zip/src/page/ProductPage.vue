<template>
  <MyHeader></MyHeader>
  <Product></Product>
</template>

<script setup lang="ts">

import Product from "@/components/Product.vue";
import MyHeader from "@/components/MyHeader.vue";
</script>

<style scoped>

</style>
