<template>
  <MyHeader></MyHeader>
  <Type></Type>
</template>

<script setup lang="ts">

import Type from "@/components/Type.vue";
import MyHeader from "@/components/MyHeader.vue";
</script>

<style>

</style>
